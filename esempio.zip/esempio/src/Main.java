import java.util.Scanner;

public class Main {
    public static Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        macchina pargheggio[] = new macchina[10];
        for (int i = 0; i < 10; i++) {
            System.out.println("inserisci la targa della macchina numero " + (i + 1));
            pargheggio[i] = new macchina(in.next(), System.currentTimeMillis());
        }
        System.out.println("quale macchina è uscita?");
        String targ = in.next();
        for (int i = 0; i < 10; i++) {
            if (pargheggio[i].getTarga() == targ) {
                System.out.println("la macchina " + pargheggio[i].getTarga() + " è rimasta pargeggiata per " + System.currentTimeMillis());
            }
        }
    }
}