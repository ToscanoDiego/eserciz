import java.sql.Timestamp;

public class macchina {
    private String targa;
    Timestamp ingr, usci;

    public macchina(String targa, long ingr) {
        this.targa = targa;
        this.ingr = new Timestamp(ingr);
        System.out.println("veicolo " + targa + " entrato in " + this.ingr);
    }

    public String getTarga() {
        return targa;
    }

    public void setTarga(String targa) {
        this.targa = targa;
    }

    public Timestamp getIngresso() {
        return ingr;
    }


    public Timestamp getUscita() {
        return usci;
    }

    public void setUscita(Timestamp usci) {
        this.usci = usci;
    }
}
